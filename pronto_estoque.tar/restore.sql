--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tem_estoque;
--
-- Name: tem_estoque; Type: DATABASE; Schema: -; Owner: tem_estoque
--

CREATE DATABASE tem_estoque WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'pt_BR.UTF-8' LC_CTYPE = 'pt_BR.UTF-8';


ALTER DATABASE tem_estoque OWNER TO tem_estoque;

\connect tem_estoque

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria_produto (
    id integer NOT NULL,
    descricao character varying(100) NOT NULL,
    ativo boolean DEFAULT true
);


ALTER TABLE public.categoria_produto OWNER TO postgres;

--
-- Name: categoria_produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_produto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_produto_id_seq OWNER TO postgres;

--
-- Name: categoria_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_produto_id_seq OWNED BY public.categoria_produto.id;


--
-- Name: cidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidade (
    id bigint NOT NULL,
    nome character varying(250) NOT NULL,
    estado_id bigint
);


ALTER TABLE public.cidade OWNER TO postgres;

--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    id bigint NOT NULL,
    nome character varying(250) NOT NULL,
    sigla character varying(2) NOT NULL,
    pais_id bigint
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fornecedor (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    email character varying(50) NOT NULL,
    telefone character(14) NOT NULL,
    rua character varying(200) NOT NULL,
    numero character varying(50) NOT NULL,
    complemento character varying(50),
    bairro character varying(50) NOT NULL,
    cep character(9) NOT NULL,
    ativo boolean DEFAULT true,
    cnpj character(18) NOT NULL,
    celular character(15) NOT NULL,
    cidade_id integer NOT NULL,
    estado_id integer NOT NULL
);


ALTER TABLE public.fornecedor OWNER TO postgres;

--
-- Name: fornecedor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fornecedor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fornecedor_id_seq OWNER TO postgres;

--
-- Name: fornecedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fornecedor_id_seq OWNED BY public.fornecedor.id;


--
-- Name: pais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pais (
    id bigint NOT NULL,
    nome character varying(250) NOT NULL,
    sigla character varying(2) NOT NULL
);


ALTER TABLE public.pais OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text NOT NULL,
    validade date,
    preco numeric(10,2),
    estoque_minimo integer NOT NULL,
    estoque_maximo integer,
    quantidade integer NOT NULL,
    dt_cadastro timestamp without time zone NOT NULL,
    dt_atualizacao timestamp without time zone NOT NULL,
    categoria_produto_id integer NOT NULL,
    fornecedor_id integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_id_seq OWNER TO postgres;

--
-- Name: produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_id_seq OWNED BY public.produto.id;


--
-- Name: system_access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_access_log (
    id integer NOT NULL,
    sessionid text,
    login text,
    login_time timestamp without time zone,
    login_year character varying(4),
    login_month character varying(2),
    login_day character varying(2),
    logout_time timestamp without time zone,
    impersonated character(1),
    access_ip character varying(45),
    impersonated_by character varying(200)
);


ALTER TABLE public.system_access_log OWNER TO postgres;

--
-- Name: system_access_notification_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_access_notification_log (
    id integer NOT NULL,
    login text,
    email text,
    ip_address text,
    login_time text
);


ALTER TABLE public.system_access_notification_log OWNER TO postgres;

--
-- Name: system_change_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_change_log (
    id integer NOT NULL,
    logdate timestamp without time zone,
    login text,
    tablename text,
    primarykey text,
    pkvalue text,
    operation text,
    columnname text,
    oldvalue text,
    newvalue text,
    access_ip text,
    transaction_id text,
    log_trace text,
    session_id text,
    class_name text,
    php_sapi text,
    log_year character varying(4),
    log_month character varying(2),
    log_day character varying(2)
);


ALTER TABLE public.system_change_log OWNER TO postgres;

--
-- Name: system_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_group (
    id integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.system_group OWNER TO postgres;

--
-- Name: system_group_program; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_group_program (
    id integer NOT NULL,
    system_group_id integer,
    system_program_id integer
);


ALTER TABLE public.system_group_program OWNER TO postgres;

--
-- Name: system_preference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_preference (
    id text,
    value text
);


ALTER TABLE public.system_preference OWNER TO postgres;

--
-- Name: system_program; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_program (
    id integer NOT NULL,
    name character varying(100),
    controller character varying(100)
);


ALTER TABLE public.system_program OWNER TO postgres;

--
-- Name: system_request_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_request_log (
    id integer NOT NULL,
    endpoint text,
    logdate text,
    log_year character varying(4),
    log_month character varying(2),
    log_day character varying(2),
    session_id text,
    login text,
    access_ip text,
    class_name text,
    http_host text,
    server_port text,
    request_uri text,
    request_method text,
    query_string text,
    request_headers text,
    request_body text,
    request_duration integer
);


ALTER TABLE public.system_request_log OWNER TO postgres;

--
-- Name: system_sql_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_sql_log (
    id integer NOT NULL,
    logdate timestamp without time zone,
    login text,
    database_name text,
    sql_command text,
    statement_type text,
    access_ip character varying(45),
    transaction_id text,
    log_trace text,
    session_id text,
    class_name text,
    php_sapi text,
    request_id text,
    log_year character varying(4),
    log_month character varying(2),
    log_day character varying(2)
);


ALTER TABLE public.system_sql_log OWNER TO postgres;

--
-- Name: system_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_unit (
    id integer NOT NULL,
    name character varying(100),
    connection_name character varying(100)
);


ALTER TABLE public.system_unit OWNER TO postgres;

--
-- Name: system_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_user (
    id integer NOT NULL,
    name character varying(100),
    login character varying(100),
    password character varying(100),
    email character varying(100),
    accepted_term_policy character(1),
    phone text,
    address text,
    function_name text,
    about text,
    accepted_term_policy_at text,
    accepted_term_policy_data text,
    frontpage_id integer,
    system_unit_id integer,
    active character(1)
);


ALTER TABLE public.system_user OWNER TO postgres;

--
-- Name: system_user_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_user_group (
    id integer NOT NULL,
    system_user_id integer,
    system_group_id integer
);


ALTER TABLE public.system_user_group OWNER TO postgres;

--
-- Name: system_user_old_password; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_user_old_password (
    id integer NOT NULL,
    system_user_id integer,
    password text,
    created_at timestamp without time zone
);


ALTER TABLE public.system_user_old_password OWNER TO postgres;

--
-- Name: system_user_program; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_user_program (
    id integer NOT NULL,
    system_user_id integer,
    system_program_id integer
);


ALTER TABLE public.system_user_program OWNER TO postgres;

--
-- Name: system_user_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_user_unit (
    id integer NOT NULL,
    system_user_id integer,
    system_unit_id integer
);


ALTER TABLE public.system_user_unit OWNER TO postgres;

--
-- Name: tipo_etiqueta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_etiqueta (
    id integer NOT NULL,
    value character(1) DEFAULT 'q'::bpchar NOT NULL,
    template_barcode text,
    template_qrcode text
);


ALTER TABLE public.tipo_etiqueta OWNER TO postgres;

--
-- Name: tipo_etiqueta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_etiqueta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_etiqueta_id_seq OWNER TO postgres;

--
-- Name: tipo_etiqueta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_etiqueta_id_seq OWNED BY public.tipo_etiqueta.id;


--
-- Name: categoria_produto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_produto ALTER COLUMN id SET DEFAULT nextval('public.categoria_produto_id_seq'::regclass);


--
-- Name: fornecedor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor ALTER COLUMN id SET DEFAULT nextval('public.fornecedor_id_seq'::regclass);


--
-- Name: produto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN id SET DEFAULT nextval('public.produto_id_seq'::regclass);


--
-- Name: tipo_etiqueta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_etiqueta ALTER COLUMN id SET DEFAULT nextval('public.tipo_etiqueta_id_seq'::regclass);


--
-- Data for Name: categoria_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria_produto (id, descricao, ativo) FROM stdin;
\.
COPY public.categoria_produto (id, descricao, ativo) FROM '$$PATH$$/3135.dat';

--
-- Data for Name: cidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cidade (id, nome, estado_id) FROM stdin;
\.
COPY public.cidade (id, nome, estado_id) FROM '$$PATH$$/3152.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado (id, nome, sigla, pais_id) FROM stdin;
\.
COPY public.estado (id, nome, sigla, pais_id) FROM '$$PATH$$/3151.dat';

--
-- Data for Name: fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fornecedor (id, nome, descricao, email, telefone, rua, numero, complemento, bairro, cep, ativo, cnpj, celular, cidade_id, estado_id) FROM stdin;
\.
COPY public.fornecedor (id, nome, descricao, email, telefone, rua, numero, complemento, bairro, cep, ativo, cnpj, celular, cidade_id, estado_id) FROM '$$PATH$$/3139.dat';

--
-- Data for Name: pais; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pais (id, nome, sigla) FROM stdin;
\.
COPY public.pais (id, nome, sigla) FROM '$$PATH$$/3150.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (id, nome, descricao, validade, preco, estoque_minimo, estoque_maximo, quantidade, dt_cadastro, dt_atualizacao, categoria_produto_id, fornecedor_id) FROM stdin;
\.
COPY public.produto (id, nome, descricao, validade, preco, estoque_minimo, estoque_maximo, quantidade, dt_cadastro, dt_atualizacao, categoria_produto_id, fornecedor_id) FROM '$$PATH$$/3137.dat';

--
-- Data for Name: system_access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_access_log (id, sessionid, login, login_time, login_year, login_month, login_day, logout_time, impersonated, access_ip, impersonated_by) FROM stdin;
\.
COPY public.system_access_log (id, sessionid, login, login_time, login_year, login_month, login_day, logout_time, impersonated, access_ip, impersonated_by) FROM '$$PATH$$/3157.dat';

--
-- Data for Name: system_access_notification_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_access_notification_log (id, login, email, ip_address, login_time) FROM stdin;
\.
COPY public.system_access_notification_log (id, login, email, ip_address, login_time) FROM '$$PATH$$/3159.dat';

--
-- Data for Name: system_change_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_change_log (id, logdate, login, tablename, primarykey, pkvalue, operation, columnname, oldvalue, newvalue, access_ip, transaction_id, log_trace, session_id, class_name, php_sapi, log_year, log_month, log_day) FROM stdin;
\.
COPY public.system_change_log (id, logdate, login, tablename, primarykey, pkvalue, operation, columnname, oldvalue, newvalue, access_ip, transaction_id, log_trace, session_id, class_name, php_sapi, log_year, log_month, log_day) FROM '$$PATH$$/3155.dat';

--
-- Data for Name: system_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_group (id, name) FROM stdin;
\.
COPY public.system_group (id, name) FROM '$$PATH$$/3140.dat';

--
-- Data for Name: system_group_program; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_group_program (id, system_group_id, system_program_id) FROM stdin;
\.
COPY public.system_group_program (id, system_group_id, system_program_id) FROM '$$PATH$$/3147.dat';

--
-- Data for Name: system_preference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_preference (id, value) FROM stdin;
\.
COPY public.system_preference (id, value) FROM '$$PATH$$/3143.dat';

--
-- Data for Name: system_program; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_program (id, name, controller) FROM stdin;
\.
COPY public.system_program (id, name, controller) FROM '$$PATH$$/3141.dat';

--
-- Data for Name: system_request_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_request_log (id, endpoint, logdate, log_year, log_month, log_day, session_id, login, access_ip, class_name, http_host, server_port, request_uri, request_method, query_string, request_headers, request_body, request_duration) FROM stdin;
\.
COPY public.system_request_log (id, endpoint, logdate, log_year, log_month, log_day, session_id, login, access_ip, class_name, http_host, server_port, request_uri, request_method, query_string, request_headers, request_body, request_duration) FROM '$$PATH$$/3158.dat';

--
-- Data for Name: system_sql_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_sql_log (id, logdate, login, database_name, sql_command, statement_type, access_ip, transaction_id, log_trace, session_id, class_name, php_sapi, request_id, log_year, log_month, log_day) FROM stdin;
\.
COPY public.system_sql_log (id, logdate, login, database_name, sql_command, statement_type, access_ip, transaction_id, log_trace, session_id, class_name, php_sapi, request_id, log_year, log_month, log_day) FROM '$$PATH$$/3156.dat';

--
-- Data for Name: system_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_unit (id, name, connection_name) FROM stdin;
\.
COPY public.system_unit (id, name, connection_name) FROM '$$PATH$$/3142.dat';

--
-- Data for Name: system_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_user (id, name, login, password, email, accepted_term_policy, phone, address, function_name, about, accepted_term_policy_at, accepted_term_policy_data, frontpage_id, system_unit_id, active) FROM stdin;
\.
COPY public.system_user (id, name, login, password, email, accepted_term_policy, phone, address, function_name, about, accepted_term_policy_at, accepted_term_policy_data, frontpage_id, system_unit_id, active) FROM '$$PATH$$/3144.dat';

--
-- Data for Name: system_user_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_user_group (id, system_user_id, system_group_id) FROM stdin;
\.
COPY public.system_user_group (id, system_user_id, system_group_id) FROM '$$PATH$$/3146.dat';

--
-- Data for Name: system_user_old_password; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_user_old_password (id, system_user_id, password, created_at) FROM stdin;
\.
COPY public.system_user_old_password (id, system_user_id, password, created_at) FROM '$$PATH$$/3149.dat';

--
-- Data for Name: system_user_program; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_user_program (id, system_user_id, system_program_id) FROM stdin;
\.
COPY public.system_user_program (id, system_user_id, system_program_id) FROM '$$PATH$$/3148.dat';

--
-- Data for Name: system_user_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_user_unit (id, system_user_id, system_unit_id) FROM stdin;
\.
COPY public.system_user_unit (id, system_user_id, system_unit_id) FROM '$$PATH$$/3145.dat';

--
-- Data for Name: tipo_etiqueta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_etiqueta (id, value, template_barcode, template_qrcode) FROM stdin;
\.
COPY public.tipo_etiqueta (id, value, template_barcode, template_qrcode) FROM '$$PATH$$/3154.dat';

--
-- Name: categoria_produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_produto_id_seq', 1, false);


--
-- Name: fornecedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fornecedor_id_seq', 1, false);


--
-- Name: produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_id_seq', 1, false);


--
-- Name: tipo_etiqueta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_etiqueta_id_seq', 1, false);


--
-- Name: categoria_produto categoria_produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_produto
    ADD CONSTRAINT categoria_produto_pkey PRIMARY KEY (id);


--
-- Name: cidade cidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (id);


--
-- Name: estado estado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pkey PRIMARY KEY (id);


--
-- Name: fornecedor fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor
    ADD CONSTRAINT fornecedor_pkey PRIMARY KEY (id);


--
-- Name: pais pais_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pais
    ADD CONSTRAINT pais_pkey PRIMARY KEY (id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (id);


--
-- Name: system_access_log system_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_access_log
    ADD CONSTRAINT system_access_log_pkey PRIMARY KEY (id);


--
-- Name: system_access_notification_log system_access_notification_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_access_notification_log
    ADD CONSTRAINT system_access_notification_log_pkey PRIMARY KEY (id);


--
-- Name: system_change_log system_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_change_log
    ADD CONSTRAINT system_change_log_pkey PRIMARY KEY (id);


--
-- Name: system_group system_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_group
    ADD CONSTRAINT system_group_pkey PRIMARY KEY (id);


--
-- Name: system_group_program system_group_program_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_group_program
    ADD CONSTRAINT system_group_program_pkey PRIMARY KEY (id);


--
-- Name: system_program system_program_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_program
    ADD CONSTRAINT system_program_pkey PRIMARY KEY (id);


--
-- Name: system_request_log system_request_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_request_log
    ADD CONSTRAINT system_request_log_pkey PRIMARY KEY (id);


--
-- Name: system_sql_log system_sql_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_sql_log
    ADD CONSTRAINT system_sql_log_pkey PRIMARY KEY (id);


--
-- Name: system_unit system_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_unit
    ADD CONSTRAINT system_unit_pkey PRIMARY KEY (id);


--
-- Name: system_user_group system_user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_group
    ADD CONSTRAINT system_user_group_pkey PRIMARY KEY (id);


--
-- Name: system_user_old_password system_user_old_password_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_old_password
    ADD CONSTRAINT system_user_old_password_pkey PRIMARY KEY (id);


--
-- Name: system_user system_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user
    ADD CONSTRAINT system_user_pkey PRIMARY KEY (id);


--
-- Name: system_user_program system_user_program_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_program
    ADD CONSTRAINT system_user_program_pkey PRIMARY KEY (id);


--
-- Name: system_user_unit system_user_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_unit
    ADD CONSTRAINT system_user_unit_pkey PRIMARY KEY (id);


--
-- Name: tipo_etiqueta tipo_etiqueta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_etiqueta
    ADD CONSTRAINT tipo_etiqueta_pkey PRIMARY KEY (id);


--
-- Name: sys_group_program_group_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_group_program_group_idx ON public.system_group_program USING btree (system_group_id);


--
-- Name: sys_group_program_program_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_group_program_program_idx ON public.system_group_program USING btree (system_program_id);


--
-- Name: sys_user_group_group_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_user_group_group_idx ON public.system_user_group USING btree (system_group_id);


--
-- Name: sys_user_group_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_user_group_user_idx ON public.system_user_group USING btree (system_user_id);


--
-- Name: sys_user_program_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_user_program_idx ON public.system_user USING btree (frontpage_id);


--
-- Name: sys_user_program_program_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_user_program_program_idx ON public.system_user_program USING btree (system_program_id);


--
-- Name: sys_user_program_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sys_user_program_user_idx ON public.system_user_program USING btree (system_user_id);


--
-- Name: cidade fkaee6572470f300d1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT fkaee6572470f300d1 FOREIGN KEY (estado_id) REFERENCES public.estado(id);


--
-- Name: estado fkb2e439664e7910fb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT fkb2e439664e7910fb FOREIGN KEY (pais_id) REFERENCES public.pais(id);


--
-- Name: fornecedor fornecedor_cidade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor
    ADD CONSTRAINT fornecedor_cidade_id_fkey FOREIGN KEY (cidade_id) REFERENCES public.cidade(id);


--
-- Name: fornecedor fornecedor_estado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor
    ADD CONSTRAINT fornecedor_estado_id_fkey FOREIGN KEY (estado_id) REFERENCES public.estado(id);


--
-- Name: produto produto_categoria_produto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_categoria_produto_id_fkey FOREIGN KEY (categoria_produto_id) REFERENCES public.categoria_produto(id);


--
-- Name: produto produto_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedor(id);


--
-- Name: system_group_program system_group_program_system_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_group_program
    ADD CONSTRAINT system_group_program_system_group_id_fkey FOREIGN KEY (system_group_id) REFERENCES public.system_group(id);


--
-- Name: system_group_program system_group_program_system_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_group_program
    ADD CONSTRAINT system_group_program_system_program_id_fkey FOREIGN KEY (system_program_id) REFERENCES public.system_program(id);


--
-- Name: system_user system_user_frontpage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user
    ADD CONSTRAINT system_user_frontpage_id_fkey FOREIGN KEY (frontpage_id) REFERENCES public.system_program(id);


--
-- Name: system_user_group system_user_group_system_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_group
    ADD CONSTRAINT system_user_group_system_group_id_fkey FOREIGN KEY (system_group_id) REFERENCES public.system_group(id);


--
-- Name: system_user_group system_user_group_system_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_group
    ADD CONSTRAINT system_user_group_system_user_id_fkey FOREIGN KEY (system_user_id) REFERENCES public.system_user(id);


--
-- Name: system_user_old_password system_user_old_password_system_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_old_password
    ADD CONSTRAINT system_user_old_password_system_user_id_fkey FOREIGN KEY (system_user_id) REFERENCES public.system_user(id);


--
-- Name: system_user_program system_user_program_system_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_program
    ADD CONSTRAINT system_user_program_system_program_id_fkey FOREIGN KEY (system_program_id) REFERENCES public.system_program(id);


--
-- Name: system_user_program system_user_program_system_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_program
    ADD CONSTRAINT system_user_program_system_user_id_fkey FOREIGN KEY (system_user_id) REFERENCES public.system_user(id);


--
-- Name: system_user system_user_system_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user
    ADD CONSTRAINT system_user_system_unit_id_fkey FOREIGN KEY (system_unit_id) REFERENCES public.system_unit(id);


--
-- Name: system_user_unit system_user_unit_system_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_unit
    ADD CONSTRAINT system_user_unit_system_unit_id_fkey FOREIGN KEY (system_unit_id) REFERENCES public.system_unit(id);


--
-- Name: system_user_unit system_user_unit_system_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_user_unit
    ADD CONSTRAINT system_user_unit_system_user_id_fkey FOREIGN KEY (system_user_id) REFERENCES public.system_user(id);


--
-- PostgreSQL database dump complete
--

